var express = require('express');
var path = require('path');
var app = express();
var bodyParser = require('body-parser');

var count = 0

app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static(path.join(__dirname, "./static")));

app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');

app.get('/', function(req, res){
	count++;
	console.log(count);
	res.render('index', {count: count});
});

app.post('/add_two', function(req, res){
	count += 1;
	console.log('Trying to add 2', count)
	res.redirect('/')
});

app.post('/reset', function(req, res){
	count = 0;
	console.log('Trying set to one', count)
	res.redirect('/')
});

app.listen(8000, function(){
	console.log('Listening on port 8000')
});